# Sound  Utilities

# Sound  Utilties is one of the Best Moderation and Utility Bot

## Can I Make this Ready Made Bot and Change it into Mine?

You can Definitely Take the Bot and Make it Yours! But Give Credit To Me. If You want More of these Things then Call it on!

## How to Setup

Just Make a File Called config.json and Put the Following Things in it.
```json
{
    "token": "YOUR_TOKEN",
    "prefix": "YOUR_DESIRED_PREFIX"
}
```

Then Open a New Terminal and Run ```
npm install```, This Will Install All Packages Needed By You, If Some errors Pop Up then DM Me on my Discord: NightMare#1458

## How to Run the Bot.

To Run the Bot Simply Just Run ```
node index.js``` And You Should be Good if You did the Steps Above!
